package com.example.myapplication1.ui.activity;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AlertDialog;
import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;
import com.example.myapplication1.R;

public class MainActivity extends AppCompatActivity implements AMapLocationListener {
    //NOTE : 加入签到时间设置，签到成功后要弹出提示框，提示签到时间地点
    private static final int MY_PERMISSIONS_REQUEST_CALL_LOCATION = 1;
    private AMapLocationClient mlocationClient;
    private AMapLocationClientOption mLocationOption;
    private SharedPreferences sharedPreferences;
    private Button signButton ;

    private static final String PREFS_NAME = "SignPrefs";
    private static final String KEY_SIGNED_IN = "signedIn";
    private static final String KEY_LAST_LATITUDE = "lastLatitude";
    private static final String KEY_LAST_LONGITUDE = "lastLongitude";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        signButton = findViewById(R.id.button);
        sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);



        signButton.setOnClickListener(view -> {
            checkIfAlreadySignedIn();
            Log.d("MainActivity", "成功点击了签到按钮");
            requestLocationPermission();
        });

        AMapLocationClient.updatePrivacyShow(this, true, true);
        AMapLocationClient.updatePrivacyAgree(this, true);
    }
    private void checkIfAlreadySignedIn() {
        boolean signedIn = sharedPreferences.getBoolean(KEY_SIGNED_IN, false);
        if (signedIn) {
            double lastLat = Double.longBitsToDouble(sharedPreferences.getLong(KEY_LAST_LATITUDE, 0));
            double lastLon = Double.longBitsToDouble(sharedPreferences.getLong(KEY_LAST_LONGITUDE, 0));
            showAlreadySignedInDialog(lastLat, lastLon);

        }
    }
    private void showAlreadySignedInDialog(double lastLat, double lastLon) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("您已经签到过了")
                .setMessage("上次签到的位置是：\n纬度: " + lastLat + "\n经度: " + lastLon + "\n是否重新签到？")
                .setPositiveButton("重新签到", (dialog, which) -> {
                    // 把 KEY_SIGNED_IN 设置为 false ，下次签到不会触发 Dialog

                    sharedPreferences.edit()
                            .putBoolean(KEY_SIGNED_IN, false).apply();


                })
                .setNegativeButton("取消", (dialog, which) -> {

                    dialog.dismiss();
                })
                .show();
    }

    private void requestLocationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, MY_PERMISSIONS_REQUEST_CALL_LOCATION);
            } else {
                showLocation();
            }
        } else {
            showLocation();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_PERMISSIONS_REQUEST_CALL_LOCATION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                showLocation();
            } else {
                Toast.makeText(this, "权限已拒绝, 不能定位", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void showLocation() {
        try {
            mlocationClient = new AMapLocationClient(this);
            mLocationOption = new AMapLocationClientOption();
            mlocationClient.setLocationListener(this);
            //设置定位模式为高精度模式，Battery_Saving为低功耗模式，Device_Sensors是仅设备模式
            mLocationOption.setLocationMode(AMapLocationClientOption.AMapLocationMode.Hight_Accuracy);
            mLocationOption.setInterval(10000);
            //设置定位参数
            mlocationClient.setLocationOption(mLocationOption);
            //启动定位
            mlocationClient.startLocation();
        } catch (Exception e) {

        }
    }

    @Override
    public void onLocationChanged(AMapLocation amapLocation) {
        if (amapLocation != null) {
            if (amapLocation.getErrorCode() == 0) {
                double latitude = amapLocation.getLatitude();
                double longitude = amapLocation.getLongitude();

                Log.d("Location", "Lat: " + latitude + ", Lon: " + longitude);
                sharedPreferences.edit()
                        .putBoolean(KEY_SIGNED_IN, true)
                        .putLong(KEY_LAST_LATITUDE, Double.doubleToRawLongBits(latitude))
                        .putLong(KEY_LAST_LONGITUDE, Double.doubleToRawLongBits(longitude))
                        .apply();

                // 只有正确签到了才会触发 Text
                boolean signedIn = sharedPreferences.getBoolean(KEY_SIGNED_IN, false);
                if (!signedIn) {
                    Toast.makeText(this, "签到成功！", Toast.LENGTH_SHORT).show();
                }


                if (mlocationClient != null) {
                    mlocationClient.stopLocation();  // 停止定位
                }
            } else {
                Log.e("AmapError", "location Error, ErrCode:" + amapLocation.getErrorCode() + ", errInfo:" + amapLocation.getErrorInfo());
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mlocationClient != null) {
            mlocationClient.onDestroy();
        }
    }
}
