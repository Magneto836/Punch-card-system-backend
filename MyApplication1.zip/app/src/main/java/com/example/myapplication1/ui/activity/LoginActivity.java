package com.example.myapplication1.ui.activity;


import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.content.Intent;
import android.util.Log;
import android.widget.EditText;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;

import com.example.myapplication1.R;
import com.example.myapplication1.databinding.ActivityLoginBinding;
import com.google.android.material.textfield.TextInputLayout;

public class LoginActivity extends AppCompatActivity {

    private static final String TAG = "LoginActivity";
    private ActivityLoginBinding binding;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityLoginBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // 获取输入框
        EditText usernameLayoutEditText = binding.tlUsername.getEditText();
        EditText passwordLayoutEditText = binding.tlPassword.getEditText();

        // 添加 TextWatcher 监听用户名输入变化
        if (usernameLayoutEditText != null) {
            usernameLayoutEditText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    // 这里可以在输入框内容改变前进行操作（可选）
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    // 当用户输入内容时，清除错误提示
                    if (s.length() > 0) {
                        binding.tlUsername.setError(null);
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {
                    // 这里可以在输入框内容改变后进行操作（可选）
                }

            });
        }
        if (passwordLayoutEditText != null) {
            passwordLayoutEditText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                    // 这里可以在输入框内容改变前进行操作（可选）
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    // 当用户输入内容时，清除错误提示
                    if (s.length() > 0) {
                        binding.tlPassword.setError(null);
                    }
                }

                @Override
                public void afterTextChanged(Editable s) {
                    // 这里可以在输入框内容改变后进行操作（可选）
                }
            });
        }
    }






    public void handleLoginBtn(View view){

        // 待补充
        Log.d(TAG, "成功点击了登录按钮");
        String username = "", password = "";

        // 获取输入框内容
        EditText usernameLayoutEditText = binding.tlUsername.getEditText();
        EditText passwordLayoutEditText = binding.tlPassword.getEditText();

        if (usernameLayoutEditText != null) {
            if (usernameLayoutEditText.getText().length() == 0) {
                Log.d(TAG, "请输入用户名");
                binding.tlUsername.setError("请输入用户名");
                return ;
            }
            username = usernameLayoutEditText.getText().toString();
            Log.d(TAG, "用户名为：" + username);
        }

        if (passwordLayoutEditText != null) {
            if (passwordLayoutEditText.getText().length() == 0) {
                binding.tlPassword.setError("请输入密码");
                Log.d(TAG, "请输入密码");

            }
            password = passwordLayoutEditText.getText().toString();
        }

        if (username.isEmpty() || password.isEmpty()) {
            Log.d(TAG, "空");
            return;
        }


        if(IfSuccessLogin(username,password)==1){
            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
            startActivity(intent);
        }

    }

    private int IfSuccessLogin(String username , String password){

       if(username.equals("123") && password.equals("456")) {  // 员工

           SharedPreferences sharedPreferences = getSharedPreferences("UserPrefs", MODE_PRIVATE);
           SharedPreferences.Editor editor = sharedPreferences.edit();
           editor.putString("username", username);
           editor.apply();
           return 1;
            }

       else return 0;
    }













}
