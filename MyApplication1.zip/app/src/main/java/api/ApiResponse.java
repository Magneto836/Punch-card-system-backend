package api;

public class ApiResponse {
    private int code;

    private String message;

    public int getCode(){
        return code ;
    }
    public String getMessage(){
        return message;
    }
}

